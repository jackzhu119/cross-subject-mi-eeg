Frozen byte copies only. Original sources and code are at https://github.com/jackzhu119/cross-subject-mi-eeg/tree/0c7146895dc46850e4fe7db38bd69d9aea2b41c3. No raw EEG or model weights.
These are publicly accessible research outputs; no new copyright license is inferred from GitHub visibility.
