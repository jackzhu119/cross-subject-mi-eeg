Frozen byte copies only. Figure renderer inputs are included without executing their renderers or recomputing statistics. No raw EEG or model weights.
Full source: https://github.com/jackzhu119/cross-subject-mi-eeg/tree/0c7146895dc46850e4fe7db38bd69d9aea2b41c3
No new copyright license is inferred from GitHub visibility.
