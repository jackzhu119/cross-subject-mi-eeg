[![DOI](https://img.shields.io/badge/DOI-10.82901%2Fnemar.nm000250-blue)](https://doi.org/10.82901/nemar.nm000250)

# Class for Dreyer2023 dataset management. MI dataset

Class for Dreyer2023 dataset management. MI dataset.

## Dataset Overview

- **Code**: Dreyer2023
- **Paradigm**: imagery
- **DOI**: 10.1038/s41597-023-02445-z
- **Subjects**: 87
- **Sessions per subject**: 1
- **Events**: left_hand=1, right_hand=2
- **Trial interval**: [0, 5] s
- **Runs per session**: 6
- **Session IDs**: calibration, online_training
- **File format**: GDF
- **Contributing labs**: Inria Bordeaux

## Acquisition

- **Sampling rate**: 512.0 Hz
- **Number of channels**: 27
- **Channel types**: eeg=27, emg=2, eog=3
- **Channel names**: C1, C2, C3, C4, C5, C6, CP1, CP2, CP3, CP4, CP5, CP6, CPz, Cz, EMGd, EMGg, EOG1, EOG2, EOG3, F3, F4, FC1, FC2, FC3, FC4, FC5, FC6, FCz, Fz, P3, P4, Pz
- **Montage**: 10-20
- **Hardware**: g.USBAmp (g.tec, Austria)
- **Software**: OpenViBE 2.1.0 (Dataset A) / OpenViBE 2.2.0 (Dataset B and C)
- **Reference**: left earlobe
- **Ground**: FPz
- **Sensor type**: active electrodes
- **Line frequency**: 50.0 Hz
- **Online filters**: none (raw signals recorded without hardware filters)
- **Cap manufacturer**: g.tec
- **Auxiliary channels**: EOG (3 ch, horizontal, vertical), EMG (2 ch), gsr

## Participants

- **Number of subjects**: 87
- **Health status**: healthy
- **Age**: mean=29.0, min=19, max=59
- **Gender distribution**: female=41, male=46
- **Handedness**: right
- **BCI experience**: naive
- **Species**: human

## Experimental Protocol

- **Paradigm**: imagery
- **Number of classes**: 2
- **Class labels**: left_hand, right_hand
- **Trial duration**: 8.0 s
- **Tasks**: right_hand_MI, left_hand_MI, resting_state
- **Study design**: Graz protocol
- **Feedback type**: continuous visual
- **Stimulus type**: blue bar varying in length
- **Stimulus modalities**: visual, auditory
- **Primary modality**: visual
- **Synchronicity**: cue-based
- **Mode**: online
- **Training/test split**: True
- **Instructions**: Participants were encouraged to perform kinesthetic imagination and leave them free to choose their mental imagery strategy. Participants were instructed to try to find the best strategy so that the system would show the longest possible feedback bar. Only positive feedback was provided.

## HED Event Annotations

Schema: HED 8.4.0 | Browse: https://www.hedtags.org/hed-schema-browser

```
  left_hand
    ├─ Sensory-event, Experimental-stimulus, Visual-presentation
    └─ Agent-action
       └─ Imagine
          ├─ Move
          └─ Left, Hand

  right_hand
    ├─ Sensory-event, Experimental-stimulus, Visual-presentation
    └─ Agent-action
       └─ Imagine
          ├─ Move
          └─ Right, Hand

```
## Paradigm-Specific Parameters

- **Detected paradigm**: motor_imagery
- **Imagery tasks**: right_hand, left_hand
- **Cue duration**: 1.25 s
- **Imagery duration**: 3.75 s

## Data Structure

- **Trials**: 240
- **Trials per class**: right_hand=120, left_hand=120
- **Blocks per session**: 6
- **Block duration**: 420.0 s
- **Trials context**: per subject (120 per class)

## Preprocessing

- **Data state**: raw
- **Preprocessing applied**: False
- **Bandpass filter**: [5.0, 35.0]
- **Filter type**: Butterworth
- **Filter order**: 5
- **Artifact methods**: visual inspection
- **Re-reference**: Laplacian (C3, C4 for feature extraction)
- **Notes**: The raw signals were recorded without any hardware filters. For online processing, a fifth-order Butterworth filter was applied in a participant-specific discriminant frequency band in the range of 5 Hz to 35 Hz with 0.5 Hz large bins. Impedance could not be measured with active electrodes; EEG signals were visually checked and regularly re-checked to ensure good signal quality.

## Signal Processing

- **Classifiers**: LDA
- **Feature extraction**: CSP, Bandpower
- **Frequency bands**: analyzed=[5.0, 35.0] Hz; alpha=[8.0, 13.0] Hz; mu=[8.0, 13.0] Hz; beta=[13.0, 30.0] Hz
- **Spatial filters**: CSP, Laplacian

## Cross-Validation

- **Method**: calibration-feedback
- **Evaluation type**: within_session

## Performance (Original Study)

- **Accuracy**: 63.35%
- **Mean Accuracy Std**: 17.36
- **Mean Accuracy R3**: 63.14
- **Mean Accuracy R4**: 64.82
- **Chance Level Individual**: 58.7
- **Chance Level Database**: 51.0

## BCI Application

- **Applications**: rehabilitation, assistive_technology, neurofeedback, user_training
- **Environment**: laboratory
- **Online feedback**: True

## Tags

- **Pathology**: Healthy
- **Modality**: Motor
- **Type**: Motor Imagery

## Documentation

- **Description**: A large EEG database with users' profile information for motor imagery brain-computer interface research. Contains electroencephalographic signals from 87 human participants, collected during a single day of brain-computer interface (BCI) experiments, organized into 3 datasets (A, B, and C) that were all recorded using the same protocol: right and left hand motor imagery (MI).
- **DOI**: 10.1038/s41597-023-02445-z
- **Associated paper DOI**: 10.1038/s41597-023-02445-z
- **License**: CC-BY-4.0
- **Investigators**: Pauline Dreyer, Aline Roc, Léa Pillette, Sébastien Rimbert, Fabien Lotte
- **Senior author**: Fabien Lotte
- **Contact**: fabien.lotte@inria.fr
- **Institution**: Centre Inria de l'université de Bordeaux
- **Department**: LaBRI (Univ. Bordeaux/CNRS/Bordeaux INP)
- **Address**: Talence, 33405, France
- **Country**: FR
- **Repository**: Zenodo
- **Data URL**: https://doi.org/10.5281/zenodo.8089820
- **Publication year**: 2023
- **Funding**: European Research Council (ERC Starting Grant project BrainConquest, grant ERC-2016-STG-714567)
- **Ethics approval**: Inria's ethics committee, the COERLE (Approval number: 2018-13)
- **Keywords**: motor imagery, brain-computer interface, EEG, BCI illiteracy, user training, personality profile, cognitive traits, user profile

## Abstract

We present and share a large database containing electroencephalographic signals from 87 human participants, collected during a single day of brain-computer interface (BCI) experiments, organized into 3 datasets (A, B, and C) that were all recorded using the same protocol: right and left hand motor imagery (MI). Each session contains 240 trials (120 per class), which represents more than 20,800 trials, or approximately 70 hours of recording time. It includes the performance of the associated BCI users, detailed information about the demographics, personality profile as well as some cognitive traits and the experimental instructions and codes (executed in the open-source platform OpenViBE). Such database could prove useful for various studies, including but not limited to: (1) studying the relationships between BCI users' profiles and their BCI performances, (2) studying how EEG signals properties varies for different users' profiles and MI tasks, (3) using the large number of participants to design cross-user BCI machine learning algorithms or (4) incorporating users' profile information into the design of EEG signal classification algorithms.

## Methodology

Participants performed a Graz protocol MI-BCI task with 6 runs (2 calibration runs with sham feedback, 4 online training runs with real feedback). Each run consisted of 40 trials (20 per MI-task) with 8s trial duration. Trial structure: green cross (t=0s), acoustic signal (t=2s), red arrow cue (t=3s, 1.25s duration), continuous visual feedback (t=4.25s, 3.75s duration), inter-trial interval (1.5-3.5s). Signal processing used participant-specific Most Discriminant Frequency Band (MDFB) selection (5-35 Hz range), fifth-order Butterworth filtering, Common Spatial Pattern (CSP) with 3 pairs of spatial filters, and Linear Discriminant Analysis (LDA) classifier trained on calibration data. Participants completed 6 questionnaires assessing demographics, personality (16PF5), cognitive traits, spatial abilities (Mental Rotation test), learning style (ILS), and pre/post-experiment states (NeXT questionnaire).

## References

Pillette, L., Roc, A., N’kaoua, B., & Lotte, F. (2021). Experimenters' influence on mental-imagery based brain-computer interface user training. International Journal of Human-Computer Studies, 149, 102603.

Benaroch, C., Yamamoto, M. S., Roc, A., Dreyer, P., Jeunet, C., & Lotte, F. (2022). When should MI-BCI feature optimization include prior knowledge, and which one?. Brain-Computer Interfaces, 9(2), 115-128.
Appelhoff, S., Sanderson, M., Brooks, T., Vliet, M., Quentin, R., Holdgraf, C., Chaumon, M., Mikulan, E., Tavabi, K., Hochenberger, R., Welke, D., Brunner, C., Rockhill, A., Larson, E., Gramfort, A. and Jas, M. (2019). MNE-BIDS: Organizing electrophysiological data into the BIDS format and facilitating their analysis. Journal of Open Source Software 4: (1896). https://doi.org/10.21105/joss.01896

Pernet, C. R., Appelhoff, S., Gorgolewski, K. J., Flandin, G., Phillips, C., Delorme, A., Oostenveld, R. (2019). EEG-BIDS, an extension to the brain imaging data structure for electroencephalography. Scientific Data, 6, 103. https://doi.org/10.1038/s41597-019-0104-8

---
Generated by MOABB 1.5.0 (Mother of All BCI Benchmarks)
https://github.com/NeuroTechX/moabb
