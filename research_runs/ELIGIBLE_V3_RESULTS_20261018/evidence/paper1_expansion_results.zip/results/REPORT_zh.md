# Paper1：扩大源训练数据后的外部评估

**状态：探索性外部验证。** Dreyer 历史使用情况不确定，因此本结果不称为首次使用的独立确认。

协议：`paper1_source_expansion_18ch_dimensionless_eligible_v3_20261018`。统计单位是 85 名外部被试；每名被试先计算各随机种子的指标，再平均 3 个种子。

## 预设主比较

S60 对 S9；BROAD；tail_min_recall 选轮；终点为每名被试较弱类别召回率。

均值差 **+21.167 个百分点**；配对 t 的 95% CI [+17.123, +25.211]；双侧 p=8.88406e-17。

被试配对 bootstrap 95% CI [+17.147, +24.951]。区间均为点态区间，没有做多重性校正。

正差表示扩源组指标较高；若区间包含零，应报告证据仍不足，不能写成已经证实改进。

## 三组数据规模

| 组 | 源被试 | 可用不同试次 | 每条轨迹优化更新数 |
|---|---:|---:|---:|
| S9 | 9 | 2592 | 5120 |
| S29 | 29 | 14590 | 5120 |
| S60 | 60 | 33183 | 5120 |

## 各组主要指标

同一 tail_min_recall 选轮规则；均先跨 3 个种子平均到被试，再跨被试求均值。

| Pipeline | 组 | 较弱类召回率 % | Balanced accuracy % |
|---|---|---:|---:|
| BROAD | S9 | 27.314 | 58.319 |
| BROAD | S29 | 49.029 | 64.108 |
| BROAD | S60 | 48.480 | 64.172 |
| MU_BETA_SHARED | S9 | 31.853 | 60.152 |
| MU_BETA_SHARED | S29 | 45.392 | 63.667 |
| MU_BETA_SHARED | S60 | 45.569 | 63.877 |

## 传统基线

固定 CSP + shrinkage LDA 使用相同的源人员和外部试次。每个规模使用 3 个种子，共 9 次拟合；该结果独立汇总，用作描述性基线，不加入神经实验的预设假设检验家族。

| 组 | 较弱类召回率 % | Balanced accuracy % |
|---|---:|---:|
| S9 | 33.990 | 60.132 |
| S29 | 45.216 | 64.020 |
| S60 | 47.814 | 65.377 |

![扩源结果](source_expansion.png)

## 次要比较

三项预设次要检验一起使用 Holm 校正；没有根据主比较是否显著而改变检验家族。

| 比较 | 差值 pp | 双侧 p | Holm p |
|---|---:|---:|---:|
| secondary_selector_min_recall | -0.873 | 0.50976 | 0.999859 |
| secondary_larger_source_min_recall | -0.549 | 0.499929 | 0.999859 |
| secondary_source_expansion_ba | +5.853 | 1.78046e-09 | 5.34139e-09 |

## 被试差异

![外部被试逐人变化](paired_subject_changes.png)

所有选择器的完整结果见 condition_summaries.csv；不得把表现最佳的外部选择器重新命名为预设主方法。

## 解释边界

- A fixed intermediate subset does not estimate all possible subset variability.
- Expansion changes both participant count and available distinct trials, and adds a different acquisition cohort; fixed updates do not identify a pure causal participant-count effect.
- The shared two-band and broadband pipelines share the same backbone family and are not independent architectures.
- Dataset mix is fixed at 50:50 when Yang is present; larger Yang cohorts lower each Yang person's sampling frequency.
- Dreyer has uncertain prior exposure and supports exploratory external validation, not first-use independent confirmation.
- This new 18-channel, dimensionless protocol is not numerically equivalent to historical 19-channel experiments.
- Yang marker timing has conflicting official-code/documentation interpretations. Its fixed marker+[2,4) window lies in both interpreted MI periods, but exact MI-phase matching to BNCI/Dreyer is not established.

## 复现材料

selection_freeze.json 给出在外部评估前冻结的全部选轮结果；source_validation_curves.csv 保存源内曲线；final_fit_manifest.csv 保存真正训练轨迹与复用检查点的对应关系；external_predictions.csv.gz 保存逐试次 logits。

逐试次结果：979,200 行。8 个选轮规则复用同一最终轨迹，不能将别名视作独立模型重复。

这些结果没有执行外部被试微调、目标标签选轮、目标集合归一化拟合或目标 BatchNorm 更新。
